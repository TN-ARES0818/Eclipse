package com.eclipse.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@SuppressLint("CustomSplashScreen")
class SplashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor     = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        // ── Star field canvas ─────────────────────────────────────────────
        val starCanvas = object : View(this) {
            val stars = Array(180) {
                floatArrayOf(
                    Random.nextFloat(),
                    Random.nextFloat(),
                    Random.nextFloat() * 2.2f + 0.3f,
                    Random.nextFloat()
                )
            }
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                stars.forEach { s ->
                    paint.alpha = (s[3] * 180 + 40).toInt().coerceIn(40, 220)
                    canvas.drawCircle(s[0] * width, s[1] * height, s[2], paint)
                }
            }
        }
        starCanvas.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        starCanvas.alpha = 0f
        root.addView(starCanvas)

        // ── Eclipse crescent SVG-like drawn with Canvas ───────────────────
        val eclipseSize = dp(180)
        val eclipseView = object : View(this) {
            val coronaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(2).toFloat()
                color = Color.parseColor("#D4A840")
                alpha = 210
            }
            val coronaGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(8).toFloat()
                color = Color.parseColor("#FFE878")
                alpha = 40
            }
            val moonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.parseColor("#06060A")
            }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val cx = width / 2f
                val cy = height / 2f
                val r  = width * 0.38f

                // Outer glow ring
                val glowGrad = RadialGradient(
                    cx - r * 0.2f, cy, r * 1.2f,
                    intArrayOf(
                        Color.parseColor("#55FFE040"),
                        Color.parseColor("#22FF9900"),
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.5f, 1f),
                    Shader.TileMode.CLAMP
                )
                val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = glowGrad
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(cx, cy, r * 1.25f, glowPaint)

                // Corona glow
                canvas.drawCircle(cx, cy, r, coronaGlowPaint)

                // Corona ring
                canvas.drawCircle(cx, cy, r, coronaPaint)

                // Eclipse shadow circle (offset to create crescent)
                canvas.drawCircle(cx + r * 0.18f, cy, r * 0.97f, moonPaint)

                // Small stars around eclipse
                val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE; alpha = 160
                }
                val starPositions = listOf(
                    Pair(0.12f, 0.28f), Pair(0.88f, 0.20f),
                    Pair(0.92f, 0.72f), Pair(0.10f, 0.78f),
                    Pair(0.75f, 0.10f), Pair(0.20f, 0.55f),
                    Pair(0.85f, 0.45f)
                )
                starPositions.forEachIndexed { i, (sx, sy) ->
                    starPaint.alpha = if (i % 2 == 0) 160 else 100
                    canvas.drawCircle(sx * width, sy * height, if (i % 3 == 0) 2.5f else 1.5f, starPaint)
                }
            }
        }
        eclipseView.layoutParams = FrameLayout.LayoutParams(eclipseSize, eclipseSize, Gravity.CENTER).apply {
            topMargin = -dp(60)
        }
        eclipseView.alpha = 0f
        root.addView(eclipseView)

        // ── Outer glow rings ──────────────────────────────────────────────
        val ringOuter = makeRing(dp(240), "#22D4A840")
        ringOuter.alpha = 0f
        root.addView(ringOuter, FrameLayout.LayoutParams(dp(240), dp(240), Gravity.CENTER).apply { topMargin = -dp(60) })

        val ringMid = makeRing(dp(210), "#33D4A840")
        ringMid.alpha = 0f
        root.addView(ringMid, FrameLayout.LayoutParams(dp(210), dp(210), Gravity.CENTER).apply { topMargin = -dp(60) })

        // ── Text stack ────────────────────────────────────────────────────
        val textStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ).apply { topMargin = dp(90) }
            alpha = 0f
        }

        val logoText = TextView(this).apply {
            text = "ECLIPSE"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 36f)
            letterSpacing = 0.35f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
        }

        val tagline = TextView(this).apply {
            text = "browse beyond"
            setTextColor(Color.parseColor("#99D4A840"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            letterSpacing = 0.30f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
        }

        textStack.addView(logoText)
        textStack.addView(tagline)
        root.addView(textStack)

        // ── Version ───────────────────────────────────────────────────────
        val versionLabel = TextView(this).apply {
            text = "Dawn 0.1"
            setTextColor(Color.parseColor("#44D4A840"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            letterSpacing = 0.2f
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(50) }
            alpha = 0f
        }
        root.addView(versionLabel)

        setContentView(root)

        // ── Animation sequence ────────────────────────────────────────────
        // 0ms: Stars fade in
        starCanvas.postDelayed({
            animateFadeIn(starCanvas, 800)
        }, 0)

        // 200ms: Eclipse orb scales in
        Handler(Looper.getMainLooper()).postDelayed({
            animateFadeScale(eclipseView, 600)
        }, 200)

        // 500ms: Rings expand
        Handler(Looper.getMainLooper()).postDelayed({
            animateFadeScale(ringMid, 500)
        }, 500)
        Handler(Looper.getMainLooper()).postDelayed({
            animateFadeScale(ringOuter, 700)
        }, 700)

        // 900ms: Text fades in
        Handler(Looper.getMainLooper()).postDelayed({
            animateFadeIn(textStack, 600)
            animateFadeIn(versionLabel, 900)
        }, 900)

        // 1300ms: Gentle pulse on eclipse
        Handler(Looper.getMainLooper()).postDelayed({
            pulseView(eclipseView)
            pulseView(ringOuter)
            // Star twinkle
            animateStarTwinkle(starCanvas)
        }, 1300)

        // 3000ms: Fade out and launch
        Handler(Looper.getMainLooper()).postDelayed({
            animateFadeOut(root, 500) {
                startActivity(Intent(this, MainActivity::class.java))
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }
        }, 3000)
    }

    private fun makeRing(size: Int, colorHex: String): View {
        return View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.parseColor(colorHex))
            }
        }
    }

    private fun animateFadeScale(view: View, duration: Long) {
        val fade = AlphaAnimation(0f, 1f).apply { this.duration = duration; fillAfter = true }
        val scale = ScaleAnimation(0.5f, 1f, 0.5f, 1f,
            Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            this.duration = duration
            interpolator = AccelerateDecelerateInterpolator()
            fillAfter = true
        }
        val set = AnimationSet(false).apply {
            addAnimation(fade); addAnimation(scale); fillAfter = true
        }
        view.alpha = 1f
        view.startAnimation(set)
    }

    private fun animateFadeIn(view: View, duration: Long) {
        val fade = AlphaAnimation(0f, 1f).apply {
            this.duration = duration; fillAfter = true
            interpolator = AccelerateDecelerateInterpolator()
        }
        view.alpha = 1f
        view.startAnimation(fade)
    }

    private fun animateFadeOut(view: View, duration: Long, onEnd: () -> Unit) {
        val fade = AlphaAnimation(1f, 0f).apply {
            this.duration = duration; fillAfter = true
            setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(a: Animation?) {}
                override fun onAnimationRepeat(a: Animation?) {}
                override fun onAnimationEnd(a: Animation?) { onEnd() }
            })
        }
        view.startAnimation(fade)
    }

    private fun pulseView(view: View) {
        val pulse = ScaleAnimation(1f, 1.06f, 1f, 1.06f,
            Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = 1200
            repeatCount = Animation.INFINITE
            repeatMode  = Animation.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        }
        view.startAnimation(pulse)
    }

    private fun animateStarTwinkle(view: View) {
        val twinkle = AlphaAnimation(0.6f, 1f).apply {
            duration = 800
            repeatCount = Animation.INFINITE
            repeatMode  = Animation.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        }
        view.startAnimation(twinkle)
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()
}
