package com.eclipse.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    // ─── URLs ────────────────────────────────────────────────────────────────
    private val HOME_URL      = "file:///android_asset/index.html"
    private val INCOG_URL     = "file:///android_asset/index.html#incognito"

    // ─── Views (all programmatic — zero XML layout needed) ──────────────────
    private lateinit var rootLayout     : RelativeLayout
    private lateinit var webContainer   : FrameLayout
    private lateinit var bottomBar      : LinearLayout
    private lateinit var tabBadge       : TextView

    // ─── WebViews ────────────────────────────────────────────────────────────
    private lateinit var mainWV     : WebView
    private lateinit var incogWV    : WebView

    // ─── State ───────────────────────────────────────────────────────────────
    private var isIncognito     = false
    private var pendingJs       : String? = null
    private var tabCount        = 1

    private val activeWV get() = if (isIncognito) incogWV else mainWV

    // ─── AD BLOCK LIST ───────────────────────────────────────────────────────
    private val BLOCKED = setOf(
        "doubleclick.net", "googlesyndication.com", "adservice.google.com",
        "googleadservices.com", "googleads.g.doubleclick.net",
        "pagead2.googlesyndication.com", "partner.googleadservices.com",
        "analytics.google.com", "google-analytics.com", "googletagmanager.com",
        "stats.g.doubleclick.net", "scorecardresearch.com", "quantserve.com",
        "chartbeat.com", "hotjar.com", "mixpanel.com", "amplitude.com",
        "adnxs.com", "adsrvr.org", "pubmatic.com", "rubiconproject.com",
        "openx.net", "criteo.com", "criteo.net", "taboola.com", "outbrain.com",
        "revcontent.com", "mgid.com", "advertising.com", "adblade.com",
        "amazon-adsystem.com", "appnexus.com", "districtm.io",
        "indexexchange.com", "sharethrough.com", "smartadserver.com",
        "triplelift.com", "connect.facebook.net", "ads.twitter.com",
        "ads.linkedin.com", "ad.youtube.com", "ads.youtube.com", "2mdn.net",
        "fls.doubleclick.net", "mc.yandex.ru", "krux.net", "bluekai.com",
        "addthis.com", "zedo.com", "moatads.com", "yieldmo.com"
    )

    // ════════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════════════════════
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Window chrome
        window.statusBarColor      = Color.BLACK
        window.navigationBarColor  = Color.parseColor("#04040C")

        buildLayout()        // creates rootLayout, webContainer, bottomBar
        setContentView(rootLayout)

        buildWebViews()      // creates mainWV + incogWV, adds to webContainer
        buildBottomNav()     // populates bottomBar with buttons

        mainWV.loadUrl(HOME_URL)
    }

    override fun onDestroy() {
        mainWV.destroy()
        incogWV.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated")
    override fun onBackPressed() {
        if (activeWV.canGoBack()) activeWV.goBack()
        else @Suppress("DEPRECATION") super.onBackPressed()
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PROGRAMMATIC LAYOUT  (no XML, no ViewBinding)
    //
    //   RelativeLayout (root, black)
    //     └── FrameLayout  webContainer   (ABOVE bottomBar)
    //     └── LinearLayout bottomBar      (ALIGN_PARENT_BOTTOM, 60dp)
    // ════════════════════════════════════════════════════════════════════════
    private fun buildLayout() {
        val navH = dp(62)

        rootLayout = RelativeLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT
            )
        }

        bottomBar = LinearLayout(this).apply {
            id        = View.generateViewId()
            orientation = LinearLayout.HORIZONTAL
            gravity   = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#04040C"))
            setPadding(dp(4), dp(4), dp(4), dp(12))
        }
        val lpBar = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT, navH
        )
        lpBar.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
        rootLayout.addView(bottomBar, lpBar)

        webContainer = FrameLayout(this)
        val lpWeb = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT,
            RelativeLayout.LayoutParams.MATCH_PARENT
        )
        lpWeb.addRule(RelativeLayout.ABOVE, bottomBar.id)
        rootLayout.addView(webContainer, lpWeb)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  WEBVIEWS
    // ════════════════════════════════════════════════════════════════════════
    @SuppressLint("SetJavaScriptEnabled")
    private fun applyWVSettings(wv: WebView, incognito: Boolean) {
        wv.settings.apply {
            javaScriptEnabled                = true
            domStorageEnabled                = !incognito
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs      = true
            allowFileAccess                  = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode                 = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE
                        else           WebSettings.LOAD_DEFAULT
            useWideViewPort        = true
            loadWithOverviewMode   = true
            loadsImagesAutomatically = true
            builtInZoomControls    = true
            displayZoomControls    = false
            setSupportZoom(true)
            userAgentString = "Mozilla/5.0 (Linux; Android 12; Pixel) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
        wv.setBackgroundColor(Color.BLACK)
        wv.isScrollbarFadingEnabled = true
    }

    private fun emptyResponse() =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    private fun makeWVClient(): WebViewClient = object : WebViewClient() {

        override fun shouldOverrideUrlLoading(wv: WebView?, req: WebResourceRequest?): Boolean {
            // Let WebView handle all navigation naturally — preserves back/forward stack
            return false
        }

        override fun onPageFinished(wv: WebView?, url: String?) {
            super.onPageFinished(wv, url)

            // Run any pending JS (tabs panel / menu open after navigating home)
            pendingJs?.let { js ->
                if (url?.startsWith("file://") == true) {
                    pendingJs = null
                    wv?.postDelayed({ wv.evaluateJavascript(js, null) }, 400)
                }
            }

            // When we return to home page → mark active tab as "home"
            if (url?.startsWith("file://") == true) {
                wv?.evaluateJavascript(
                    "try{" +
                    "var t=App&&App.tabs&&App.tabs.find(function(x){return x.id===App.activeTabId;});" +
                    "if(t){t.url='home';t.title='New Tab';" +
                    "if(typeof Store!=='undefined')Store.saveTabs(App.tabs);}" +
                    "}catch(e){}", null
                )
            }

            // Save history (normal tabs, external pages only)
            if (!isIncognito && url != null && !url.startsWith("file://")) {
                val title  = (wv?.title ?: "").replace("'", "\\'").take(80)
                val safeUrl = url.replace("'", "\\'").take(300)
                wv?.evaluateJavascript(
                    "try{if(typeof Store!=='undefined')Store.addHistory('$safeUrl','$title');}catch(e){}",
                    null
                )
            }
        }

        override fun shouldInterceptRequest(wv: WebView?, req: WebResourceRequest?): WebResourceResponse? {
            val url = req?.url?.toString()?.lowercase() ?: return null
            // Block known ad / tracker domains
            for (domain in BLOCKED) {
                if (url.contains(domain)) return emptyResponse()
            }
            // Block YouTube instream ads
            if ((url.contains("youtube.com") || url.contains("googlevideo.com")) &&
                (url.contains("pagead") || url.contains("instream_ad") ||
                 url.contains("api/stats/ads") || url.contains("doubleclick"))) {
                return emptyResponse()
            }
            return super.shouldInterceptRequest(wv, req)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebViews() {
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )

        mainWV = WebView(this).apply {
            layoutParams = lp
            applyWVSettings(this, false)
            addJavascriptInterface(Bridge(), "Android")
            webViewClient  = makeWVClient()
            webChromeClient = WebChromeClient()
        }

        // Separate isolated WebView for incognito — completely different session
        incogWV = WebView(this).apply {
            layoutParams = lp
            applyWVSettings(this, true)
            addJavascriptInterface(Bridge(), "Android")
            webViewClient  = makeWVClient()
            webChromeClient = WebChromeClient()
            visibility = View.GONE
        }

        webContainer.addView(mainWV)
        webContainer.addView(incogWV)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  NATIVE BOTTOM NAV — 5 buttons, always visible
    // ════════════════════════════════════════════════════════════════════════
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    /** plain icon button */
    private fun iconBtn(icon: String, colorHex: String = "#88ffffff"): TextView {
        return TextView(this).apply {
            text = icon
            textSize = 21f
            setTextColor(Color.parseColor(colorHex))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 1f
            )
            isClickable = true
            isFocusable  = true
        }
    }

    private fun buildBottomNav() {
        // ← Back
        iconBtn("←").also { btn ->
            btn.setOnClickListener { if (activeWV.canGoBack()) activeWV.goBack() }
            bottomBar.addView(btn)
        }

        // → Forward
        iconBtn("→").also { btn ->
            btn.setOnClickListener { if (activeWV.canGoForward()) activeWV.goForward() }
            bottomBar.addView(btn)
        }

        // ⌂ Home — centre button with orange glow ring
        val homeFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val homeBtn = TextView(this).apply {
            text     = "⌂"
            textSize = 23f
            setTextColor(Color.parseColor("#ff6b1a"))
            gravity  = Gravity.CENTER
            isClickable = true
            isFocusable  = true
            layoutParams = FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#22ff6b1a"))
                setStroke(dp(1), Color.parseColor("#77ff6b1a"))
            }
        }
        homeBtn.setOnClickListener {
            if (activeWV.url?.startsWith("file://") == true) {
                activeWV.evaluateJavascript("try{navHome();}catch(e){}", null)
            } else {
                activeWV.loadUrl(if (isIncognito) INCOG_URL else HOME_URL)
            }
        }
        homeFrame.addView(homeBtn)
        bottomBar.addView(homeFrame)

        // ⧉ Tabs — with orange badge
        val tabsFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val tabsBtn = TextView(this).apply {
            text     = "⧉"
            textSize = 21f
            setTextColor(Color.parseColor("#88ffffff"))
            gravity  = Gravity.CENTER
            isClickable = true
            isFocusable  = true
            layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER)
        }
        tabBadge = TextView(this).apply {
            textSize = 8f
            setTextColor(Color.WHITE)
            gravity  = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#ff6b1a"))
            }
            layoutParams = FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(6), dp(4), 0)
            }
            visibility = View.GONE
        }
        tabsBtn.setOnClickListener { openTabsAction() }
        tabsFrame.addView(tabsBtn)
        tabsFrame.addView(tabBadge)
        bottomBar.addView(tabsFrame)

        // ⋮ Menu
        iconBtn("⋮").also { btn ->
            btn.setOnClickListener { openMenuAction() }
            bottomBar.addView(btn)
        }
    }

    // ─── Tab & menu actions ──────────────────────────────────────────────────
    private fun openTabsAction() {
        if (activeWV.url?.startsWith("file://") == true) {
            activeWV.evaluateJavascript("try{openTabsPanel();}catch(e){}", null)
        } else {
            pendingJs = "try{openTabsPanel();}catch(e){}"
            activeWV.loadUrl(if (isIncognito) INCOG_URL else HOME_URL)
        }
    }

    private fun openMenuAction() {
        if (activeWV.url?.startsWith("file://") == true) {
            activeWV.evaluateJavascript("try{openMenu();}catch(e){}", null)
        } else {
            pendingJs = "try{openMenu();}catch(e){}"
            activeWV.loadUrl(if (isIncognito) INCOG_URL else HOME_URL)
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  INCOGNITO SWITCH
    // ════════════════════════════════════════════════════════════════════════
    private fun enterIncognito() {
        isIncognito = true
        mainWV.visibility  = View.GONE
        incogWV.visibility = View.VISIBLE
        // Kill cookies + cache in incognito WebView
        CookieManager.getInstance().setAcceptCookie(false)
        CookieManager.getInstance().removeAllCookies(null)
        incogWV.clearCache(true)
        incogWV.clearHistory()
        incogWV.loadUrl(INCOG_URL)
        runOnUiThread { setTabBadge(tabCount + 1) }
    }

    private fun exitIncognito() {
        isIncognito = false
        // Wipe incognito WebView completely
        incogWV.loadUrl("about:blank")
        incogWV.clearCache(true)
        incogWV.clearHistory()
        CookieManager.getInstance().removeAllCookies(null)
        incogWV.visibility = View.GONE
        // Restore cookies for normal browsing
        CookieManager.getInstance().setAcceptCookie(true)
        mainWV.visibility = View.VISIBLE
        runOnUiThread { setTabBadge(tabCount) }
    }

    private fun setTabBadge(count: Int) {
        tabCount = count
        if (count > 1) {
            tabBadge.text = count.toString()
            tabBadge.visibility = View.VISIBLE
        } else {
            tabBadge.visibility = View.GONE
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  JS ↔ KOTLIN BRIDGE
    // ════════════════════════════════════════════════════════════════════════
    inner class Bridge {

        @JavascriptInterface
        fun openUrl(url: String) = runOnUiThread { activeWV.loadUrl(url) }

        @JavascriptInterface
        fun goHome() = runOnUiThread {
            activeWV.loadUrl(if (isIncognito) INCOG_URL else HOME_URL)
        }

        @JavascriptInterface
        fun goBack() = runOnUiThread {
            if (activeWV.canGoBack()) activeWV.goBack()
        }

        @JavascriptInterface
        fun goForward() = runOnUiThread {
            if (activeWV.canGoForward()) activeWV.goForward()
        }

        @JavascriptInterface
        fun openIncognito() = runOnUiThread { enterIncognito() }

        @JavascriptInterface
        fun exitIncognito() = runOnUiThread { this@MainActivity.exitIncognito() }

        @JavascriptInterface
        fun updateTabCount(count: Int) = runOnUiThread { setTabBadge(count) }

        @JavascriptInterface
        fun isIncognitoMode(): Boolean = isIncognito

        @JavascriptInterface
        fun getCurrentUrl(): String = activeWV.url ?: ""

        // Fetch any URL from Kotlin (bypasses WebView file:// CORS restrictions)
        // Used by JS for news RSS, etc.
        @JavascriptInterface
        fun fetchUrl(url: String, callbackId: String) {
            Thread {
                try {
                    val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        setRequestProperty("User-Agent",
                            "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
                        setRequestProperty("Accept", "text/html,application/xml,*/*")
                        connectTimeout = 12000
                        readTimeout    = 12000
                        instanceFollowRedirects = true
                    }
                    val bytes   = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                        ?.readBytes() ?: ByteArray(0)
                    val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    runOnUiThread {
                        activeWV.evaluateJavascript(
                            "try{EclFetchCallback('$callbackId','$encoded',null);}catch(e){}", null)
                    }
                } catch (e: Exception) {
                    val err = (e.message ?: "fetch error").replace("'", "\\'").take(120)
                    runOnUiThread {
                        activeWV.evaluateJavascript(
                            "try{EclFetchCallback('$callbackId',null,'$err');}catch(e){}", null)
                    }
                }
            }.start()
        }
    }
}
